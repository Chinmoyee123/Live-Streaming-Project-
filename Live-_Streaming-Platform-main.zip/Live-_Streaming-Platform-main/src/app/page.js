import LiveStreamPlatform from "@/components/live-stream-platform";

export default function Home() {
  return (
    <div>
      <LiveStreamPlatform/>
    </div>
  );
}
